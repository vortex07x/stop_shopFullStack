// src/pages/Admin.js
import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import styled, { keyframes } from "styled-components";

const Admin = () => {
  const navigate = useNavigate();
  const [activeSection, setActiveSection] = useState('dashboard');
  const [adminStats, setAdminStats] = useState({
    totalUsers: 0,
    totalProducts: 0,
    totalOrders: 0,
    totalRevenue: 0
  });
  const [loading, setLoading] = useState(true);
  
  const userRole = localStorage.getItem("userRole") || "";
  const userName = localStorage.getItem("userName") || "Admin";
  const userEmail = localStorage.getItem("userEmail") || "";
  const token = localStorage.getItem("token");
  const isAdmin = userRole.toUpperCase() === 'ADMIN';

  // Redirect non-admin users
  useEffect(() => {
    if (!token || !isAdmin) {
      navigate("/404");
      return;
    }
    
    // Fetch admin stats when component mounts
    fetchAdminStats();
  }, [navigate, token, isAdmin]);

  const fetchAdminStats = async () => {
    try {
      setLoading(true);
      
      if (!token) {
        console.log("No token found");
        return;
      }

      // This is a placeholder - you'll need to implement these endpoints
      const response = await fetch("http://localhost:8080/api/admin/stats", {
        method: "GET",
        headers: {
          "Authorization": `Bearer ${token}`,
          "Content-Type": "application/json"
        }
      });

      if (response.ok) {
        const stats = await response.json();
        setAdminStats(stats);
      } else {
        console.log("Failed to fetch admin stats:", response.status);
        // Set some placeholder data for now
        setAdminStats({
          totalUsers: 156,
          totalProducts: 89,
          totalOrders: 234,
          totalRevenue: 15670.50
        });
      }
    } catch (error) {
      console.log("Error fetching admin stats:", error);
      // Set some placeholder data for now
      setAdminStats({
        totalUsers: 156,
        totalProducts: 89,
        totalOrders: 234,
        totalRevenue: 15670.50
      });
    } finally {
      setLoading(false);
    }
  };

  const navigationItems = [
    {
      id: 'dashboard',
      label: 'Dashboard',
      icon: (
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect x="3" y="3" width="7" height="7" rx="1" stroke="currentColor" strokeWidth="2"/>
          <rect x="14" y="3" width="7" height="7" rx="1" stroke="currentColor" strokeWidth="2"/>
          <rect x="14" y="14" width="7" height="7" rx="1" stroke="currentColor" strokeWidth="2"/>
          <rect x="3" y="14" width="7" height="7" rx="1" stroke="currentColor" strokeWidth="2"/>
        </svg>
      )
    },
    {
      id: 'users',
      label: 'User Details',
      icon: (
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" stroke="currentColor" strokeWidth="2"/>
          <circle cx="12" cy="7" r="4" stroke="currentColor" strokeWidth="2"/>
        </svg>
      )
    },
    {
      id: 'orders',
      label: 'User Orders',
      icon: (
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2" stroke="currentColor" strokeWidth="2"/>
          <rect x="8" y="2" width="8" height="4" rx="1" ry="1" stroke="currentColor" strokeWidth="2"/>
        </svg>
      )
    },
    {
      id: 'products',
      label: 'Products',
      icon: (
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z" stroke="currentColor" strokeWidth="2"/>
          <polyline points="3.27,6.96 12,12.01 20.73,6.96" stroke="currentColor" strokeWidth="2"/>
          <line x1="12" y1="22.08" x2="12" y2="12" stroke="currentColor" strokeWidth="2"/>
        </svg>
      )
    }
  ];

  if (!token || !isAdmin) {
    return null; // This will be handled by useEffect redirect
  }

  const renderDashboard = () => (
    <>
      {/* Stats Grid */}
      <div className="stats-grid">
        <div className="stat-card users">
          <div className="stat-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" stroke="currentColor" strokeWidth="2"/>
              <circle cx="12" cy="7" r="4" stroke="currentColor" strokeWidth="2"/>
            </svg>
          </div>
          <div className="stat-content">
            <div className="stat-number">
              {loading ? <div className="loading-skeleton"></div> : adminStats.totalUsers}
            </div>
            <div className="stat-label">Total Users</div>
          </div>
        </div>

        <div className="stat-card products">
          <div className="stat-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z" stroke="currentColor" strokeWidth="2"/>
              <polyline points="3.27,6.96 12,12.01 20.73,6.96" stroke="currentColor" strokeWidth="2"/>
              <line x1="12" y1="22.08" x2="12" y2="12" stroke="currentColor" strokeWidth="2"/>
            </svg>
          </div>
          <div className="stat-content">
            <div className="stat-number">
              {loading ? <div className="loading-skeleton"></div> : adminStats.totalProducts}
            </div>
            <div className="stat-label">Total Products</div>
          </div>
        </div>

        <div className="stat-card orders">
          <div className="stat-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2" stroke="currentColor" strokeWidth="2"/>
              <rect x="8" y="2" width="8" height="4" rx="1" ry="1" stroke="currentColor" strokeWidth="2"/>
            </svg>
          </div>
          <div className="stat-content">
            <div className="stat-number">
              {loading ? <div className="loading-skeleton"></div> : adminStats.totalOrders}
            </div>
            <div className="stat-label">Total Orders</div>
          </div>
        </div>

        <div className="stat-card revenue">
          <div className="stat-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <line x1="12" y1="1" x2="12" y2="23" stroke="currentColor" strokeWidth="2"/>
              <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6" stroke="currentColor" strokeWidth="2"/>
            </svg>
          </div>
          <div className="stat-content">
            <div className="stat-number">
              {loading ? <div className="loading-skeleton"></div> : `$${adminStats.totalRevenue.toFixed(2)}`}
            </div>
            <div className="stat-label">Total Revenue</div>
          </div>
        </div>
      </div>

      {/* Coming Soon Notice */}
      <div className="coming-soon">
        <div className="coming-soon-content">
          <div className="coming-soon-icon">
            <svg width="48" height="48" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="2"/>
              <path d="M8 14s1.5 2 4 2 4-2 4-2" stroke="currentColor" strokeWidth="2"/>
              <line x1="9" y1="9" x2="9.01" y2="9" stroke="currentColor" strokeWidth="2"/>
              <line x1="15" y1="9" x2="15.01" y2="9" stroke="currentColor" strokeWidth="2"/>
            </svg>
          </div>
          <h3>Admin Features Coming Soon!</h3>
          <p>We're working hard to bring you comprehensive admin management tools. Stay tuned for exciting updates!</p>
        </div>
      </div>
    </>
  );

  const renderUsers = () => (
    <div className="section-content">
      <div className="section-header">
        <h2>User Management</h2>
        <p>Manage all registered users and their accounts</p>
      </div>
      <div className="placeholder-content">
        <div className="placeholder-icon">
          <svg width="64" height="64" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" stroke="currentColor" strokeWidth="2"/>
            <circle cx="9" cy="7" r="4" stroke="currentColor" strokeWidth="2"/>
            <path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75" stroke="currentColor" strokeWidth="2"/>
          </svg>
        </div>
        <h3>User Details Section</h3>
        <p>This section will display user information including:</p>
        <ul>
          <li>User profiles and account details</li>
          <li>Registration dates and activity status</li>
          <li>User roles and permissions</li>
          <li>Account management actions</li>
        </ul>
      </div>
    </div>
  );

  const renderOrders = () => (
    <div className="section-content">
      <div className="section-header">
        <h2>Order Management</h2>
        <p>View and manage all customer orders</p>
      </div>
      <div className="placeholder-content">
        <div className="placeholder-icon">
          <svg width="64" height="64" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" stroke="currentColor" strokeWidth="2"/>
            <polyline points="14,2 14,8 20,8" stroke="currentColor" strokeWidth="2"/>
            <line x1="16" y1="13" x2="8" y2="13" stroke="currentColor" strokeWidth="2"/>
            <line x1="16" y1="17" x2="8" y2="17" stroke="currentColor" strokeWidth="2"/>
          </svg>
        </div>
        <h3>Order Details Section</h3>
        <p>This section will display order information including:</p>
        <ul>
          <li>Order status and tracking</li>
          <li>Customer information and shipping details</li>
          <li>Order items and pricing</li>
          <li>Order history and analytics</li>
        </ul>
      </div>
    </div>
  );

  const renderProducts = () => (
    <div className="section-content">
      <div className="section-header">
        <h2>Product Management</h2>
        <p>Manage your product catalog and inventory</p>
      </div>
      <div className="placeholder-content">
        <div className="placeholder-icon">
          <svg width="64" height="64" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z" stroke="currentColor" strokeWidth="2"/>
            <polyline points="3.27,6.96 12,12.01 20.73,6.96" stroke="currentColor" strokeWidth="2"/>
            <line x1="12" y1="22.08" x2="12" y2="12" stroke="currentColor" strokeWidth="2"/>
          </svg>
        </div>
        <h3>Product Details Section</h3>
        <p>This section will display product information including:</p>
        <ul>
          <li>Product listings and details</li>
          <li>Inventory management</li>
          <li>Product categories and tags</li>
          <li>Pricing and discount management</li>
        </ul>
      </div>
    </div>
  );

  const renderContent = () => {
    switch (activeSection) {
      case 'dashboard':
        return renderDashboard();
      case 'users':
        return renderUsers();
      case 'orders':
        return renderOrders();
      case 'products':
        return renderProducts();
      default:
        return renderDashboard();
    }
  };

  return (
    <Wrapper>
      <div className="admin-layout">
        {/* Left Sidebar Navigation */}
        <div className="sidebar">
          <div className="sidebar-header">
            <div className="admin-badge">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 2L2 7v10c0 5.55 3.84 9.74 9 9 5.16.74 9-3.45 9-9V7l-9-5z" stroke="currentColor" strokeWidth="2" fill="currentColor"/>
                <path d="M9 12l2 2 4-4" stroke="white" strokeWidth="2" fill="none"/>
              </svg>
              <span>ADMIN</span>
            </div>
          </div>
          
          <nav className="sidebar-nav">
            {navigationItems.map((item) => (
              <button
                key={item.id}
                className={`nav-item ${activeSection === item.id ? 'active' : ''}`}
                onClick={() => setActiveSection(item.id)}
              >
                <span className="nav-icon">{item.icon}</span>
                <span className="nav-label">{item.label}</span>
                <div className="tooltip">{item.label}</div>
              </button>
            ))}
          </nav>

          <div className="sidebar-footer">
            <Link to="/profile" className="back-to-profile">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M19 12H5M12 19l-7-7 7-7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              Back to Profile
            </Link>
          </div>
        </div>

        {/* Main Content Area */}
        <div className="main-content">
          {/* Header */}
          <div className="content-header">
            <div className="header-info">
              <h1>Admin Dashboard</h1>
              <div className="admin-info">
                <p>Welcome back, <strong>{userName}</strong></p>
                <p className="admin-email">{userEmail}</p>
              </div>
            </div>
          </div>

          {/* Dynamic Content */}
          <div className="content-body">
            {renderContent()}
          </div>
        </div>
      </div>
    </Wrapper>
  );
};

export default Admin;

// Animations
const fadeIn = keyframes`
  from { opacity: 0; transform: translateY(30px); }
  to { opacity: 1; transform: translateY(0); }
`;

const shimmer = keyframes`
  0% { background-position: -200px 0; }
  100% { background-position: calc(200px + 100%) 0; }
`;

const slideIn = keyframes`
  from { opacity: 0; transform: translateX(-20px); }
  to { opacity: 1; transform: translateX(0); }
`;

const float = keyframes`
  0% { transform: translateY(0px); }
  50% { transform: translateY(-10px); }
  100% { transform: translateY(0px); }
`;

const Wrapper = styled.section`
  min-height: 100vh;
  background: linear-gradient(135deg, #1e3a5f 0%, #2d5a87 100%);
  display: flex;

  .admin-layout {
    display: flex;
    width: 100%;
    height: 100vh;
  }

  /* Left Sidebar */
  .sidebar {
    width: 80px;
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(10px);
    box-shadow: 4px 0 20px rgba(0, 0, 0, 0.1);
    display: flex;
    flex-direction: column;
    overflow-y: auto;
  }

  .sidebar-header {
    padding: 2rem 1rem;
    border-bottom: 1px solid #e2e8f0;
    display: flex;
    justify-content: center;

    .admin-badge {
      background: linear-gradient(135deg, #ffd700, #ff6b35);
      color: white;
      padding: 12px;
      border-radius: 12px;
      font-size: 1.2rem;
      font-weight: 700;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 4px 12px rgba(255, 215, 0, 0.3);
      width: 48px;
      height: 48px;

      span {
        display: none;
      }

      svg {
        width: 24px;
        height: 24px;
      }
    }
  }

  .sidebar-nav {
    flex: 1;
    padding: 1rem 0;

    .nav-item {
      width: 100%;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 1.2rem 0;
      background: none;
      border: none;
      cursor: pointer;
      color: #4a5568;
      font-size: 1rem;
      font-weight: 500;
      transition: all 0.3s ease;
      border-left: 4px solid transparent;
      position: relative;

      &:hover {
        background: rgba(66, 153, 225, 0.1);
        color: #2b6cb0;

        .tooltip {
          opacity: 1;
          visibility: visible;
          transform: translateX(0);
        }
      }

      &.active {
        background: linear-gradient(90deg, rgba(66, 153, 225, 0.15) 0%, transparent 100%);
        color: #2b6cb0;
        border-left-color: #4299e1;
        font-weight: 600;

        .nav-icon {
          color: #4299e1;
        }
      }

      .nav-icon {
        transition: color 0.3s ease;

        svg {
          width: 28px;
          height: 28px;
        }
      }

      .nav-label {
        display: none;
      }

      .tooltip {
        position: absolute;
        left: 100%;
        top: 50%;
        transform: translateY(-50%) translateX(-10px);
        background: #2d3748;
        color: white;
        padding: 8px 12px;
        border-radius: 6px;
        font-size: 0.9rem;
        font-weight: 500;
        white-space: nowrap;
        opacity: 0;
        visibility: hidden;
        transition: all 0.3s ease;
        z-index: 1000;
        margin-left: 10px;

        &::before {
          content: '';
          position: absolute;
          right: 100%;
          top: 50%;
          transform: translateY(-50%);
          border: 5px solid transparent;
          border-right-color: #2d3748;
        }
      }
    }
  }

  .sidebar-footer {
    padding: 1.5rem;
    border-top: 1px solid #e2e8f0;

    .back-to-profile {
      width: 100%;
      background: #4299e1;
      color: white;
      padding: 12px 16px;
      border-radius: 8px;
      text-decoration: none;
      display: flex;
      align-items: center;
      gap: 8px;
      font-weight: 600;
      transition: all 0.3s ease;
      justify-content: center;

      &:hover {
        background: #3182ce;
        transform: translateY(-1px);
      }
    }
  }

  /* Main Content */
  .main-content {
    flex: 1;
    display: flex;
    flex-direction: column;
    overflow: hidden;
  }

  .content-header {
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(10px);
    padding: 2rem;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);

    .header-info {
      h1 {
        font-size: 2.5rem;
        font-weight: 700;
        color: #2d3748;
        margin: 0 0 1rem 0;
        animation: ${fadeIn} 0.6s ease-out;
      }

      .admin-info {
        p {
          margin: 0.25rem 0;
          color: #4a5568;
          font-size: 1.1rem;
        }

        .admin-email {
          color: #718096;
          font-size: 1rem;
        }
      }
    }
  }

  .content-body {
    flex: 1;
    padding: 2rem;
    overflow-y: auto;
    animation: ${slideIn} 0.6s ease-out;
  }

  /* Stats Grid (Dashboard) */
  .stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 1.5rem;
    margin-bottom: 3rem;

    .stat-card {
      background: rgba(255, 255, 255, 0.95);
      backdrop-filter: blur(10px);
      padding: 2rem;
      border-radius: 16px;
      display: flex;
      align-items: center;
      gap: 1.5rem;
      box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
      transition: all 0.3s ease;

      &:hover {
        transform: translateY(-4px);
        box-shadow: 0 12px 40px rgba(0, 0, 0, 0.15);
      }

      .stat-icon {
        width: 60px;
        height: 60px;
        border-radius: 16px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
      }

      &.users .stat-icon {
        background: linear-gradient(135deg, #667eea, #764ba2);
      }

      &.products .stat-icon {
        background: linear-gradient(135deg, #f093fb, #f5576c);
      }

      &.orders .stat-icon {
        background: linear-gradient(135deg, #4facfe, #00f2fe);
      }

      &.revenue .stat-icon {
        background: linear-gradient(135deg, #43e97b, #38f9d7);
      }

      .stat-content {
        .stat-number {
          font-size: 2rem;
          font-weight: 700;
          color: #2d3748;
          margin-bottom: 0.5rem;

          .loading-skeleton {
            width: 80px;
            height: 32px;
            background: linear-gradient(90deg, #f0f0f0 25%, #e0e0e0 50%, #f0f0f0 75%);
            background-size: 200% 100%;
            animation: ${shimmer} 1.5s infinite;
            border-radius: 8px;
          }
        }

        .stat-label {
          color: #718096;
          font-weight: 600;
          font-size: 1rem;
        }
      }
    }
  }

  /* Section Content (for non-dashboard sections) */
  .section-content {
    .section-header {
      background: rgba(255, 255, 255, 0.95);
      backdrop-filter: blur(10px);
      padding: 2rem;
      border-radius: 16px;
      margin-bottom: 2rem;
      box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);

      h2 {
        color: #2d3748;
        font-size: 2rem;
        font-weight: 700;
        margin: 0 0 0.5rem 0;
      }

      p {
        color: #718096;
        font-size: 1.1rem;
        margin: 0;
      }
    }

    .placeholder-content {
      background: rgba(255, 255, 255, 0.95);
      backdrop-filter: blur(10px);
      padding: 3rem;
      border-radius: 16px;
      text-align: center;
      box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);

      .placeholder-icon {
        color: #4299e1;
        margin-bottom: 1.5rem;
        animation: ${float} 3s ease-in-out infinite;
      }

      h3 {
        color: #2d3748;
        font-size: 1.8rem;
        font-weight: 700;
        margin-bottom: 1rem;
      }

      p {
        color: #718096;
        font-size: 1.1rem;
        line-height: 1.6;
        margin-bottom: 1.5rem;
      }

      ul {
        text-align: left;
        max-width: 400px;
        margin: 0 auto;
        color: #4a5568;

        li {
          margin: 0.5rem 0;
          padding-left: 1rem;
          position: relative;

          &::before {
            content: "•";
            color: #4299e1;
            position: absolute;
            left: 0;
            font-weight: bold;
          }
        }
      }
    }
  }

  /* Coming Soon Section */
  .coming-soon {
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(10px);
    padding: 3rem;
    border-radius: 16px;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
    text-align: center;

    .coming-soon-content {
      max-width: 600px;
      margin: 0 auto;

      .coming-soon-icon {
        color: #4299e1;
        margin-bottom: 1.5rem;
        animation: ${float} 3s ease-in-out infinite;
      }

      h3 {
        color: #2d3748;
        font-size: 2rem;
        font-weight: 700;
        margin-bottom: 1rem;
      }

      p {
        color: #718096;
        font-size: 1.1rem;
        line-height: 1.6;
        margin-bottom: 2rem;
      }
    }
  }

  /* Mobile Responsive */
  @media (max-width: 768px) {
    .admin-layout {
      flex-direction: column;
      height: auto;
    }

    .sidebar {
      width: 100%;
      height: auto;
      order: 2;
    }

    .main-content {
      order: 1;
    }

    .content-header {
      h1 {
        font-size: 2rem;
      }
    }

    .stats-grid {
      grid-template-columns: 1fr; //
      gap: 1rem;

      .stat-card {
        padding: 1.5rem;
      }
    }

    .section-content .placeholder-content {
      padding: 2rem;

      h3 {
        font-size: 1.5rem;
      }
    }

    .sidebar-nav .nav-item {
      padding: 0.8rem 1rem;
      font-size: 0.9rem;
    }

    .content-body {
      padding: 1rem;
    }
  }

  @media (max-width: 1024px) {
    .sidebar {
      width: 240px;
    }

    .sidebar-nav .nav-item {
      padding: 0.8rem 1rem;

      .nav-label {
        font-size: 0.9rem;
      }
    }

    .stats-grid {
      grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
    }
  }
`;